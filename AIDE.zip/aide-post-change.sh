#!/bin/bash
TOOL_INPUT="${CLAUDE_TOOL_INPUT:-}"
FILE_PATH=$(echo "$TOOL_INPUT" | grep -o '"path":"[^"]*"' | head -1 | sed 's/"path":"//;s/"//')
TIMESTAMP=$(date '+%Y-%m-%d %H:%M')
[ -z "$FILE_PATH" ] && exit 0

for skip in "CLAUDE.md" "AIDE_CONFIG" "CODEBASE_MAP" "ERROR_LEDGER" \
            "CHANGE_LOG" "PENDING_APPROVALS" "TEAM_LOG" "AIDE_HEALTH" \
            "/.claude/" "/pm/" "/finance/" "/docs/"; do
  [[ "$FILE_PATH" == *"$skip"* ]] && exit 0
done

CHANGELOG="$CLAUDE_PROJECT_DIR/CHANGE_LOG.md"
if [ -f "$CHANGELOG" ]; then
  ENTRY="- [PENDIENTE] $TIMESTAMP — $(basename $FILE_PATH) — [FEAT/FIX/REFACTOR] — [descripción]"
  sed -i "s|## \[Unreleased\]|## [Unreleased]\n$ENTRY|" "$CHANGELOG" 2>/dev/null || true
fi
exit 0
