# Team Log — [NOMBRE DEL PROYECTO]

> Registro de decisiones tomadas en el proyecto.
> En modo Solo: decisiones que tomaste y por qué — útil para recordar el razonamiento.

---

## DEC-001 — Inicialización con AIDE v2.1

**Fecha:** [FECHA]
**Decisión:** Usar AIDE v2.1 como metodología de desarrollo
**Razón:** Control de cambios, memoria institucional y eficiencia con IA
**Impacto:** Toda la estructura del proyecto sigue los protocolos AIDE
