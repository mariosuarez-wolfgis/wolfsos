#!/bin/bash
TOOL_INPUT="${CLAUDE_TOOL_INPUT:-}"
FILE_PATH=$(echo "$TOOL_INPUT" | grep -o '"path":"[^"]*"' | head -1 | sed 's/"path":"//;s/"//')
[ -z "$FILE_PATH" ] && exit 0

BLOCKED=(
  "\.env$" "\.env\.local$" "\.env\.production$" "\.env\.staging$"
  "secrets/" "credentials/" "_SECRET" "_PRIVATE_KEY"
  "id_rsa" "\.pem$" "\.key$"
)

for p in "${BLOCKED[@]}"; do
  if echo "$FILE_PATH" | grep -qE "$p"; then
    echo "[AIDE-SECRETS] ⛔ Bloqueado: $FILE_PATH"
    echo "Archivo de secretos — AIDE no accede a este archivo."
    echo "Solo se permite leer .env.example"
    exit 1
  fi
done

exit 0
