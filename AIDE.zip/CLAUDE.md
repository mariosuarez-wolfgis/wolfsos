# AIDE v2.1 — Instrucciones maestras para Claude Code
# Modo: Solo | Proyecto nuevo

## Lectura obligatoria al inicio de cada sesión (en este orden)
1. AIDE_CONFIG.json        → fase actual y configuración
2. CODEBASE_MAP.md         → leer ANTES de cualquier cambio de código
3. ERROR_LEDGER.md         → consultar ANTES de implementar cualquier cosa
4. PENDING_APPROVALS.md    → verificar si hay algo bloqueado
5. PROJECT_CHARTER.md      → límites y alcance del proyecto

## Quién soy y cómo me diriges
- Soy el único miembro del equipo. Tengo todos los roles.
- Cuando necesites una decisión técnica, una decisión de producto
  o una aprobación financiera: soy yo en todos los casos.
- Si algo parece salirse del alcance definido en PROJECT_CHARTER.md,
  detenme y alértame antes de proceder.

## Reglas absolutas
- NUNCA edites código sin haber ejecutado el PCP primero
- NUNCA toques un archivo marcado FROZEN sin mi confirmación explícita
- NUNCA generes código con credenciales, API keys ni passwords reales
- NUNCA leas .env ni archivos de secretos — solo .env.example
- SIEMPRE actualiza CODEBASE_MAP.md + CHANGE_LOG.md después de cada cambio
- SIEMPRE registra en ERROR_LEDGER.md si algo salió inesperadamente
- Si el contexto de la sesión supera 10-12 turnos o cambia de tema,
  indícame: "[AIDE] Abre una sesión nueva — el contexto está en los archivos."

## Modelo y esfuerzo por tipo de tarea
| Tarea                                  | Modelo   | Esfuerzo |
|----------------------------------------|----------|----------|
| Consultas, status, budget, logs        | Haiku    | Low      |
| Código normal, features, PCP CAUTION   | Sonnet   | Medium   |
| Arquitectura, PCP FROZEN, debugging    | Sonnet   | High     |
| Planificación de fase completa         | Opus     | High     |

Indícame al inicio de cada sesión qué tipo de tarea haremos
para que elijas el modelo correcto.

## En modo incidente (algo falla en producción)
Escribe "MODO INCIDENTE" al inicio de la sesión.
El PCP se simplifica. Todo queda registrado para revisión posterior.

## Señal de secreto detectado
Si encuentras algo que parece una credencial en el código:
detente, enmascáralo y alértame antes de continuar.
