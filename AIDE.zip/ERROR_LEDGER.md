# Error Ledger — [NOMBRE DEL PROYECTO]

> Proyecto nuevo — sin errores registrados aún.
> AIDE actualiza este archivo automáticamente cuando algo sale mal.

---

## Cómo leer este archivo

Antes de implementar cualquier cosa, la IA consulta este archivo
buscando errores relacionados con el cambio propuesto.

Severidades: Crítica / Alta / Media / Baja
Categorías: #database #security #performance #integration
            #deployment #architecture #configuration #dependency #incident #secrets

---

## Errores registrados

> Ninguno aún. El primer error se registrará aquí.

---

## Plantilla para nuevas entradas

```
## ERROR-[N]: [Título descriptivo]

**Fecha:** [fecha]
**Severidad:** [Crítica / Alta / Media / Baja]
**Módulo:** [MOD-XX]
**Fase:** [BUILD / DEPLOY / INCIDENT]

### Descripción
[Qué pasó]

### Causa raíz
[Por qué ocurrió]

### Solución aplicada
[Qué se hizo]

### Prevención futura
[Qué hacer para que no vuelva a ocurrir]

### Tags
#[categoría]
```
