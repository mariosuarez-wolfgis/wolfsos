# Project Charter — [NOMBRE DEL PROYECTO]

> Estado: BORRADOR — completar en el onboarding
> Generado por: AIDE v2.1
> Fecha: [FECHA]

---

## Problema que resuelve
[Descripción en 1-2 oraciones]

## Objetivo de éxito medible
[Qué métrica confirma que el proyecto funcionó]

## Modo de trabajo
- Desarrollador: Solo
- Roles: Todos los roles recaen en una persona

## Alcance del MVP — qué INCLUYE
1. [funcionalidad 1]
2. [funcionalidad 2]
3. [funcionalidad 3]

## Alcance — qué está EXPLÍCITAMENTE EXCLUIDO
1. [exclusión 1]
2. [exclusión 2]

> Cualquier petición fuera de esta lista dispara una alerta de alcance en AIDE.

## Stack tecnológico
- Backend: [COMPLETAR]
- Frontend: [COMPLETAR]
- Base de datos: [COMPLETAR]
- Cloud / hosting: [COMPLETAR]

## Repositorio
- URL: [COMPLETAR]
- Branching: trunk-based (PRs directos a main)

## Presupuesto
- Total: $[COMPLETAR]
- Moneda: [COMPLETAR]
- Incluye: [COMPLETAR]

## Fechas
- Inicio: [FECHA]
- Fin estimado: [FECHA]

## Deuda técnica inicial
Ninguna — proyecto nuevo.

## Historial de cambios al charter
| Fecha | Cambio | Razón |
|-------|--------|-------|
| [fecha] | Creación inicial | Onboarding AIDE |
