# Budget — [NOMBRE DEL PROYECTO]

**Nivel de control:** Nivel 1 — Simple
**Moneda:** [COMPLETAR]
**Última actualización:** [FECHA]

---

## Resumen

| Concepto | Monto |
|----------|-------|
| Presupuesto total aprobado | $[COMPLETAR] |
| Gastado a la fecha | $0 |
| Saldo disponible | $[COMPLETAR] |

**Salud financiera:** 🟢 Sin gastos aún

---

## Registro de gastos

| ID | Fecha | Descripción | Categoría | Monto | Notas |
|----|-------|-------------|-----------|-------|-------|

---

## Alertas disparadas

> Ninguna aún. AIDE alertará al 80% del presupuesto consumido.
