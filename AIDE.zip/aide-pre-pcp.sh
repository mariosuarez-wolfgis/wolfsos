#!/bin/bash
TOOL_INPUT="${CLAUDE_TOOL_INPUT:-}"
FILE_PATH=$(echo "$TOOL_INPUT" | grep -o '"path":"[^"]*"' | head -1 | sed 's/"path":"//;s/"//')
[ -z "$FILE_PATH" ] && exit 0

# Permitir archivos AIDE y directorios de configuración
for skip in "CLAUDE.md" "AIDE_CONFIG" "CODEBASE_MAP" "ERROR_LEDGER" \
            "CHANGE_LOG" "PENDING_APPROVALS" "TEAM_LOG" "AIDE_HEALTH" \
            "/.claude/" "/pm/" "/finance/" "/docs/" ".env.example"; do
  [[ "$FILE_PATH" == *"$skip"* ]] && exit 0
done

echo "[AIDE-PCP] Editando: $(basename $FILE_PATH)"
echo "Asegúrate de haber completado el PCP antes de continuar."
exit 0
