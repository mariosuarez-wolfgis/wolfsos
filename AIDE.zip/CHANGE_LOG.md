# Change Log — [NOMBRE DEL PROYECTO]

> Formato: [TIPO] TASK-ID — Descripción — Archivos tocados — Fecha
> Tipos: FEAT / FIX / REFACTOR / DOCS / SECURITY / INFRA / AIDE / INCIDENT

---

## [Unreleased]

## [0.1.0] — [FECHA]
### AIDE
- [AIDE] Inicialización del proyecto con AIDE v2.1
