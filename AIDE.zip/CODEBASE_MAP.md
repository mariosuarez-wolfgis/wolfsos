# CODEBASE MAP — [NOMBRE DEL PROYECTO]

> Versión: 0.1 — generado en el onboarding (proyecto vacío)
> Última actualización: [FECHA]
> Actualizar después de cada sesión de desarrollo.

---

## Índice de módulos

| ID | Módulo | Ruta | Zona | Descripción breve |
|----|--------|------|------|------------------|
| MOD-01 | [nombre] | /src/[ruta]/ | SAFE | [qué hace] |

> Las zonas se asignarán cuando exista código.
> Por ahora todo es SAFE hasta que se identifiquen módulos críticos.

---

## Reglas globales para la IA

```
REGLA-01: Buscar el módulo en este mapa ANTES de proponer cualquier cambio.
REGLA-02: Si el módulo es FROZEN: DETENER y notificar al usuario.
REGLA-03: Si el módulo es CAUTION: análisis completo + esperar "APROBADO".
REGLA-04: Listar los archivos EXACTOS a tocar con líneas aproximadas.
REGLA-05: Listar los archivos que PODRÍAN verse afectados indirectamente.
REGLA-06: Si algo no está en el mapa: DETENER y actualizar el mapa primero.
REGLA-07: Actualizar este archivo después de cada cambio aprobado.
REGLA-08: Si supera 800 líneas: dividir en /codebase/[modulo].md
```

---

## Estructura del proyecto (completar en la Fase ARCH)

```
[NOMBRE]/
├── [estructura de directorios — completar]
```

---

## Dependencias entre módulos

> Completar cuando existan al menos 2 módulos.

---

## Notas del desarrollador

> Espacio para anotar decisiones técnicas informales que no llegan a un ADR.
